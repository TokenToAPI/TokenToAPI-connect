TokenToAPI Connect 0.1.0 · macOS Apple Silicon

After extracting, open TokenToAPI Connect.app; you can also drag it into the Applications folder.
Choose a gateway → choose a client → enter your API Key → fetch and select models → import.
After importing, fully quit the target client, then reopen it and start a new session.
To revert, click "Restore original configuration" in the top-right corner.

This package uses an ad-hoc signature and has not yet completed Apple Developer ID signing or notarization.
If the system blocks it, first confirm that you downloaded it from this project's GitHub Release, then follow the system prompt.

Source & docs: https://github.com/TokenToAPI/TokenToAPI-connect
Latest verification notes: https://github.com/TokenToAPI/TokenToAPI-connect/blob/main/VERIFICATION.md
